/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    char startvalue;
    char choiceAgain;
    float onlineShoping(void);
    startlevel:
    cout<<"please press s to start shoping"<<endl;
    start:
    cin>>startvalue;
    if(startvalue=='s'||startvalue=='S')
    {
        float totalamount=onlineShoping();
        cout<<"total BillAmount is "<<totalamount;
        shopAgain:
        cout<<" \n Do you want to shopping y or n"<<endl;
        cin>>choiceAgain;
        if(choiceAgain=='y'||choiceAgain=='Y')
        {
            goto startlevel;
        }
        else if(choiceAgain=='n'||choiceAgain=='N')
        {
            cout<<"thanks for shoping"<<endl;
        }
         else{
             cout<<"you have enter wrong option please type again"<<endl;
             goto shopAgain;
         }
    }
    else{
        cout<<"you have enter wrong option please press s"<<endl;
        goto start;
    }
    
}
float onlineShoping()
{
    char item;
    float billamount=0;
    char choice;
    int quantity;
    itemlevel:
    cout<<"*******Welcome to online shopping*******"<<endl;
    cout<<"------------please flow the instruction---------------"<<endl;
    cout<<"(1)please enter m to order mobile phone"<<endl;
     cout<<"(2)please enter l to order laptop"<<endl;
     cout<<"(3)please enter d to order desktop"<<endl;
     cout<<"(4)please enter s to order speaker"<<endl;
     cout<<"(5)please enter h to order headphone"<<endl;
     cout<<"(6)please enter c to order charging"<<endl;
     cin>>choice;
     
     //for mobile 
     if(choice=='m'||choice=='M')
     {
         mobilelevel:
         cout<<"mobile details"<<endl;
         cout<<"(1)apple  => price:  40000"<<endl;
          cout<<"(2)vivo  => price:  25000"<<endl;
           cout<<"(3)oppo  => price:  20000"<<endl;
            cout<<"(4)redmi  => price:  18000"<<endl;
             cout<<"(5)sumsung  => price:  30000"<<endl;
              cout<<"(6) realme  => price:  17000"<<endl;
              cout<<"please enter yout choice"<<endl;
              cin>>item;
              if(item=='1')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                billamount=billamount+quantity*40000;  
              }
              else if(item=='2')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                   billamount=billamount+quantity*25000; 
              }
              else if(item=='3')
              {
             
                 cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*20000;  
              }
              else if(item=='4')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*18000; 
                  
              }
              else if(item=='5')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*30000; 
              }
              else if(item=='6')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*17000; 
              }
               else{
        cout<<"you have enter wrong option please press again"<<endl;
        goto mobilelevel;
    }
     }
       //desktob
     else if(choice=='d'||choice=='D')
     {
         desktoblevel:
         cout<<"desktob details"<<endl;
         cout<<"(1)sony  => price:  40000"<<endl;
          cout<<"(2)hp  => price:  25000"<<endl;
           cout<<"(3)dell  => price:  20000"<<endl;
            cout<<"(4)asus  => price:  18000"<<endl;
             cout<<"(5)lenovo  => price:  30000"<<endl;
              cout<<"(6) realme  => price:  17000"<<endl;
              cout<<"please enter yout choice"<<endl;
              cin>>item;
              if(item=='1')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                billamount=billamount+quantity*40000;  
              }
              else if(item=='2')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                   billamount=billamount+quantity*25000; 
              }
              else if(item=='3')
              {
             
                 cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*20000;  
              }
              else if(item=='4')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*18000; 
                  
              }
              else if(item=='5')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*30000; 
              }
              else if(item=='6')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*17000; 
              }
               else{
        cout<<"you have enter wrong option please press again"<<endl;
        goto desktoblevel;
    }
     }
      //laptop
     else if(choice=='l'||choice=='L')
     {
         laptoplevel:
         cout<<"laptop details"<<endl;
         cout<<"(1)sony  => price:  40000"<<endl;
          cout<<"(2)hp  => price:  25000"<<endl;
           cout<<"(3)dell  => price:  20000"<<endl;
            cout<<"(4)asus  => price:  18000"<<endl;
             cout<<"(5)lenovo  => price:  30000"<<endl;
              cout<<"(6) realme  => price:  17000"<<endl;
              cout<<"please enter yout choice"<<endl;
              cin>>item;
              if(item=='1')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                billamount=billamount+quantity*40000;  
              }
              else if(item=='2')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                   billamount=billamount+quantity*25000; 
              }
              else if(item=='3')
              {
             
                 cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*20000;  
              }
              else if(item=='4')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*18000; 
                  
              }
              else if(item=='5')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*30000; 
              }
              else if(item=='6')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*17000; 
              }
               else{
        cout<<"you have enter wrong option please press again"<<endl;
        goto laptoplevel;
    }
     }
      //speaker
     else if(choice=='s'||choice=='S')
     {
         speakerlevel:
         cout<<"speaker details"<<endl;
         cout<<"(1)sony  => price:  4000"<<endl;
          cout<<"(2)boat  => price:  2500"<<endl;
           cout<<"(3)boalt  => price:  2000"<<endl;
            cout<<"(4)sumsung  => price:  1800"<<endl;
             cout<<"(5)lenovo  => price:  3000"<<endl;
              cout<<"(6) realme  => price:  1700"<<endl;
              cout<<"please enter yout choice"<<endl;
              cin>>item;
              if(item=='1')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                billamount=billamount+quantity*4000;  
              }
              else if(item=='2')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                   billamount=billamount+quantity*2500; 
              }
              else if(item=='3')
              {
             
                 cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*2000;  
              }
              else if(item=='4')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*1800; 
                  
              }
              else if(item=='5')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*3000; 
              }
              else if(item=='6')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*1700; 
              }
               else{
        cout<<"you have enter wrong option please press again"<<endl;
        goto speakerlevel;
    }
     }
      //headphone
     else if(choice=='h'||choice=='H')
     {
         headphonelevel:
         cout<<"headphone details"<<endl;
         cout<<"(1)sony  => price:  400"<<endl;
          cout<<"(2)boat => price:  250"<<endl;
           cout<<"(3)dell  => price:  200"<<endl;
            cout<<"(4)asus  => price:  180"<<endl;
             cout<<"(5)lenovo  => price:  300"<<endl;
              cout<<"(6) realme  => price:  170"<<endl;
              cout<<"please enter yout choice"<<endl;
              cin>>item;
              if(item=='1')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                billamount=billamount+quantity*400;  
              }
              else if(item=='2')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                   billamount=billamount+quantity*250; 
              }
              else if(item=='3')
              {
             
                 cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*200;  
              }
              else if(item=='4')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*180; 
                  
              }
              else if(item=='5')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*300; 
              }
              else if(item=='6')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*170; 
              }
               else{
        cout<<"you have enter wrong option please press again"<<endl;
        goto headphonelevel;
    }
     }
      //charging
     else if(choice=='c'||choice=='C')
     {
         charginglevel:
         cout<<"charging details"<<endl;
         cout<<"(1)sony  => price:  1000"<<endl;
          cout<<"(2)hp  => price:  500"<<endl;
           cout<<"(3)dell  => price:  200"<<endl;
            cout<<"(4)asus  => price:  180"<<endl;
             cout<<"(5)lenovo  => price:  400"<<endl;
              cout<<"(6) realme  => price:  750"<<endl;
              cout<<"please enter yout choice"<<endl;
              cin>>item;
              if(item=='1')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                billamount=billamount+quantity*1000;  
              }
              else if(item=='2')
              {
                  cout<<"enter quantity"<<endl;
                  cin>>quantity;
                   billamount=billamount+quantity*500; 
              }
              else if(item=='3')
              {
             
                 cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*200;  
              }
              else if(item=='4')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*180; 
                  
              }
              else if(item=='5')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*400; 
              }
              else if(item=='6')
              {
                    cout<<"enter quantity"<<endl;
                  cin>>quantity;
                  billamount=billamount+quantity*750; 
              }
               else{
        cout<<"you have enter wrong option please press again"<<endl;
        goto charginglevel;
    }
     }
    else{
     cout<<"you have enter wrong option please press again"<<endl;
        goto itemlevel;
     }
     return billamount;
    
    }